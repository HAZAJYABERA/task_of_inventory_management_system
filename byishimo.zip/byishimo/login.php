

<!DOCTYPE html>
<html lang="en">
<!-- My Name hazajyabera samuel 222003581-->
<head>
    <link rel="stylesheet" type="text/css" href="style.css" title="style 1" media="screen, tv, projection, handheld, print"/>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Login</title>
</head>

<body>
<center>
    <h2 style="background-color:yellow; width: 500px; height: 50px;">
    Login Form</h2>
    <form action="login.php" method="post" style="background-color: pink; width: 500px; height: 200px;">
        <label>Email:</label>
        <input type="email" name="email" required><br><br>
        <label>Password:</label>
        <input type="password" name="password" required>
     
     <p style="font-size: 20px;"><a href="resetpassword.php">Forgot Password</a></p>

        <input type="submit" value="Login">
        <input type="reset" value="Cancel">
        
    <p style="font-size: 20px;"><i>Don't have an account?</i> <a href="register.html">
        Create New Account</a></p>
    </form>
</center>
</body>
</html>

<?php
// Include the database connection file
include("database.php");

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    // Retrieve the form data
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Hash the password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Prepare the SQL statement to insert the user's data
    $stmt = $connection->prepare("INSERT INTO user (email, password) VALUES (?, ?)");
    if ($stmt === false) {
        // Handle error - notify administrator, log to a file, show an error screen, etc.
        die('prepare() failed: ' . htmlspecialchars($connection->error));
    }

    $stmt->bind_param("ss", $email, $hashed_password);

    // Execute the SQL statement
    if ($stmt->execute()) {
        // Redirect the user to the home.html page
        header("Location: home.html");
        exit();
    } else {
        // Display an error message
        echo "Error registering user: " . htmlspecialchars($stmt->error);
    }

    // Close the statement and the database connection
    $stmt->close();
    $connection->close();
}
?>
